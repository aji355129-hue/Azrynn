import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "6107205970").split()))

API_ID = int(os.getenv("API_ID", "23330707"))

API_HASH = os.getenv("API_HASH", "00c006849545d8af56ef6447c9b60808")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8586659988:AAFEE-HmFXZWkHm0kazlc_ncpRIGZI-rP-M")

OWNER_ID = int(os.getenv("OWNER_ID", "6107205970"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://Ubot:aji2015_@ubotazrynn.mk2nvde.mongodb.net/ubot?retryWrites=true&w=majority")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003527611232"))
